package com.example.shopping_cart_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
